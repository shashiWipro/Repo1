import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AppRoutingModule} from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowStudentComponent } from './student/show-student/show-student.component';
import { AddStudentComponent } from './student/add-student/add-student.component';
import {FormsModule} from '@angular/forms';
import { StudentPipe } from './student/student.pipe';
import {HttpClientModule} from '@angular/common/http';
import {ReactiveFormsModule} from '@angular/forms';
import { StudentService } from './student/student.service';
import { CreditscoreComponent } from './student/creditscore/creditscore.component';
@NgModule({
  declarations: [
    AppComponent,
    ShowStudentComponent,
    AddStudentComponent,
    StudentPipe,
    CreditscoreComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [StudentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
