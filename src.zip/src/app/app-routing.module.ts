import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddStudentComponent } from './student/add-student/add-student.component';
import { ShowStudentComponent } from './student/show-student/show-student.component';
import { CreditscoreComponent } from './student/creditscore/creditscore.component';

const routes: Routes = [
{path:"create",component:AddStudentComponent},
{path:"show",component:ShowStudentComponent},
{path:"creditscore",component:CreditscoreComponent},
{path:"**",component:AddStudentComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
