import { Injectable } from '@angular/core';
import { IStudent } from './istudent';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Scorelist } from './creditscore/scorelist';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
  baseUrl="http://localhost:3000/employees";
  //baseUrl="http://localhost:3000/employees?first_name=bhushan";
  creditcardBaseurl="http://localhost:3000/creditcard?pancard=AFEPY123";
  creditcardBaseurl1="http://localhost:3000/creditcard?pancard=";
   studentsList:IStudent[]=[
   {id:111,first_name:"shashi bhushan",last_name:"bhushan",email:"bhushansjce@gmail.com"},
   {id:222,first_name:"uma shamkar",last_name:"bhushan",email:"bhushansjce@gmail.com"},
   {id:333,first_name:"Umesh g",last_name:"bhushan",email:"bhushansjce@gmail.com"}];
  constructor(private _http:HttpClient) { }
 
  getStudents():Observable<IStudent[]>
  {
        return this._http.get<IStudent[]>(this.baseUrl);
  }

  deleteStudent(sid:number):Observable<void>
  {
    console.log(this.baseUrl);
    console.log(sid);
     return this._http.delete<void>(`${this.baseUrl}/${sid}`);
     window.location.reload(true);
  }

  filterStudentByName(first_name:string):Observable<IStudent[]>
  {
    return this._http.get<IStudent[]>(this.baseUrl+"?first_name="+first_name);
  }

  getScoreByPAN(pancard:string):Observable<Scorelist>
  {
     return this._http.get<Scorelist>(this.creditcardBaseurl1+pancard);
  }

}
