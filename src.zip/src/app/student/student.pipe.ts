import { Pipe, PipeTransform } from '@angular/core';
import { IStudent } from './istudent';

@Pipe({
  name: 'student'
})
export class StudentPipe implements PipeTransform {

  transform(students:IStudent[], searchTerm:string): IStudent[] {
    if(!students || !searchTerm)
    {
       return students;
    }

 return students.filter(student=>
                        student.first_name.toLowerCase().indexOf(searchTerm.toLowerCase()) ==-1);
                      
  }

}
