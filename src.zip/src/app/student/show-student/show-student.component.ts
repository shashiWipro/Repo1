import { Component, OnInit } from '@angular/core';
import { IStudent } from '../istudent';
import { StudentService } from '../student.service';
import {Router} from '@angular/router';
import { ThrowStmt } from '@angular/compiler';
@Component({
  selector: 'app-show-student',
  templateUrl: './show-student.component.html',
  styleUrls: ['./show-student.component.css']
})
export class ShowStudentComponent implements OnInit {
  students:IStudent[];
  searchText:string;
  constructor(private _studentService:StudentService,
              private _router:Router) { }

  ngOnInit() {
   // this._studentService.getStudents().subscribe(
   //   (studentList)=>this.students=studentList
   // );
  
     this._studentService.filterStudentByName("Amit").subscribe(
       (selectedStudentList)=>this.students=selectedStudentList
     );

  }

  
  deleteButtonClick(sid:number)
  {
    this._studentService.deleteStudent(sid).subscribe(
    ()=>this._router.navigate(['/show'])
   );
   window.location.reload(true);
  }
  
}
