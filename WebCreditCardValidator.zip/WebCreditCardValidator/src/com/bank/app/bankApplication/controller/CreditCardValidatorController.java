package com.bank.app.bankApplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bank.app.bankApplication.entity.CreditCardDetails;
import com.bank.app.bankApplication.service.CreditCardValidatorService;



@RestController
public class CreditCardValidatorController {


@Autowired
private CreditCardValidatorService service;

@PostMapping("/savedata/{scoreDetails}")
public String saveCreditDetails(@RequestBody CreditCardDetails scoreDetails)
{
	return service.saveCreditScoreDetails(scoreDetails);
}



@GetMapping("/")
public String showCredit()
{
	  return "index.html";
}

@RequestMapping(value = "/index", method = RequestMethod.GET)
public String index() {
   return "index";
}


@GetMapping(value ="/getscore/{panCardNo}",produces ="text/html")
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "http://localhost:6001")
@CrossOrigin(origins = "*")
public  String getCreditScore(@PathVariable("panCardNo") String panCardNo)
{       if(panCardNo.isEmpty() || null==panCardNo)
      {
	return "Pan Card Field Can not be Empty";
	 
      }
		
else
    {
	return service.getCreditScore(panCardNo);
   }
	
}

}




