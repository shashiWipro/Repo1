package com.bank.app.bankApplication.commandLineRunner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.bank.app.bankApplication.dao.CreditScoreDAO;
import com.bank.app.bankApplication.entity.CreditCardDetails;
@Component
public class CreditCardValidatorCommandLineRunner
 implements CommandLineRunner {

   
	@Autowired
	private CreditScoreDAO creditScoreDAO;
	
	@Override
	public void run(String... args) throws Exception {

		saveCreditScoreDetails();
		
		
	}
public void saveCreditScoreDetails()
{
	
	
	
	CreditCardDetails score1=new CreditCardDetails("AXSSP1122H", 3.10);
	CreditCardDetails score2=new CreditCardDetails("APPSA3355P",8.50);
	CreditCardDetails score3=new CreditCardDetails("AXVPS7766V", 1.50);
	CreditCardDetails score4=new CreditCardDetails("ASXPS2121S", 5.10);
	CreditCardDetails score5=new CreditCardDetails("APPXA2244X",9.50);
	creditScoreDAO.save(score1);
	creditScoreDAO.save(score2);
	creditScoreDAO.save(score3);
	creditScoreDAO.save(score4);
	creditScoreDAO.save(score5);
}

	



	
}
