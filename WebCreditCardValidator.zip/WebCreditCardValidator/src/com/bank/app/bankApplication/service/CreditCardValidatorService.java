package com.bank.app.bankApplication.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.app.bankApplication.dao.CreditScoreDAO;
import com.bank.app.bankApplication.entity.CreditCardDetails;

@Service
public class CreditCardValidatorService {
    @Autowired
	private CreditScoreDAO creditScoreDao;
    
    public String saveCreditScoreDetails(CreditCardDetails cardDetails)
    {
    	if(null != cardDetails)
    	{
    		creditScoreDao.save(cardDetails);
    		return "Details Saved Successfully";
    	}
    	
    	else
    	{
    		return "Invalid Request";
    	}
    }

public List<String> getAllPanCard()
{
	List<String> panList=new ArrayList<String>();
 List<CreditCardDetails> creditCardList = creditScoreDao.findAll();
 for(CreditCardDetails ccd:creditCardList)
 {
	 panList.add(ccd.getPancard());
 }
 return panList;
}
    
    
    public  String getCreditScore( String panCardNo)
    {    
    	List<String> allPanCard = getAllPanCard();
    CreditCardDetails findByPancard = creditScoreDao.findByPancard(panCardNo);
    if (allPanCard.contains(panCardNo))
           {
    	 if (findByPancard.getCreditscore()>=5) 
    	                  {
    			//return "Congratulations !!! you are eligible for credit card";
    			//return "<html><body><h1 style='color:red'>Congratulations !!! you are eligible for credit card</h1></body></html>";
    		     return "eligible";
    		              }
    	    else
    	         {
    	    	//return "Sorry !!! you are not eligible for credit card";
    	    	return "notEligible";
    	          }
    	    		
	        }
    
    else
         {
    	//return "Invalid Pan Entry !!!";
    	return "invalid";
         }
    }

    
}
