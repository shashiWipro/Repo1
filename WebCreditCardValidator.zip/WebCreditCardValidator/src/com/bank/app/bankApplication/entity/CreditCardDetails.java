package com.bank.app.bankApplication.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="CreditCardDetails")
public class CreditCardDetails {
	
   @Id
   @GeneratedValue
   @JsonProperty("id")
	private Integer id;
   @JsonProperty("pancard")
	private String pancard;
   @JsonProperty("creditscore")
	private Double creditscore;
public CreditCardDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public CreditCardDetails(String pancard, Double creditscore) {
	super();
	this.pancard = pancard;
	this.creditscore = creditscore;
}



public CreditCardDetails(Integer id, String pancard, Double creditscore) {
	super();
	this.id = id;
	this.pancard = pancard;
	this.creditscore = creditscore;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getPancard() {
	return pancard;
}
public void setPancard(String pancard) {
	this.pancard = pancard;
}
public Double getCreditscore() {
	return creditscore;
}
public void setCreditscore(Double creditscore) {
	this.creditscore = creditscore;
}
@Override
public String toString() {
	return "CreditCardDetails [id=" + id + ", pancard=" + pancard + ", creditscore=" + creditscore + "]";
}
	
	
	
	
}
