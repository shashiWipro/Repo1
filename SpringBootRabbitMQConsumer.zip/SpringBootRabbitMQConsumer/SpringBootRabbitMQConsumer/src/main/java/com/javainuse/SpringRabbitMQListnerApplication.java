package com.javainuse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRabbitMQListnerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRabbitMQListnerApplication.class, args);
	}
}
