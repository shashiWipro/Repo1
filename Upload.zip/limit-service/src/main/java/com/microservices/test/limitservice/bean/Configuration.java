package com.microservices.test.limitservice.bean;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("limit-service")
public class Configuration {

	private int minimum;
	private int miximum;
	private String result;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public Configuration() {
		
	}
	public Configuration(int minimum, int miximum) {
		super();
		this.minimum = minimum;
		this.miximum = miximum;
	}
	public int getMinimum() {
		return minimum;
	}
	public void setMinimum(int minimum) {
		this.minimum = minimum;
	}
	public int getMiximum() {
		return miximum;
	}
	public void setMiximum(int miximum) {
		this.miximum = miximum;
	}
	
	
}
