package com.application.price.service.priceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
