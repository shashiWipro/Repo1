package com.product.microservices.productservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.product.microservices.productservice.businessservice.ProductService;
import com.product.microservices.productservice.entity.Product;
import com.product.microservices.productservice.feignProxy.PriceServiceProxy;

@RestController
public class ProductController {
	
@Autowired
private	ProductService productService;

@Autowired
private PriceServiceProxy proxy;	


@GetMapping("/product-service/listAll")	
public List<Product> findAllProducts()
	{
		return productService.findAllProducts();
	}



@GetMapping("/product-service/{productId}")	
public Product findProductById(@PathVariable String productId)
{
	return productService.findProductById(productId);
}


@GetMapping("/product-service/{productId}/{quantities}")	
public Product findProductWithPrice(@PathVariable String productId,@PathVariable Integer quantities )
{
	 Product prodFromProdService=productService.findProductById(productId);
	 Product productDetails = proxy.findByProductId(productId, quantities); 
	 prodFromProdService.setPrice(productDetails.getPrice());
	 
	 prodFromProdService.setPort(productDetails.getPort());
	 //return new Product(productDetails.getProductId(), productDetails.getProductName(), productDetails.getProductCategory(), productDetails.getPrice());
     return prodFromProdService;
}

@GetMapping("/product-service")
public List<Product> findProductsDetailsUsingFeign()
{
	 List<Product> findAll = proxy.findAll();
	 List<Product> products=productService.findAllProducts();
	 for(Product prod:products)
	 {
		for(Product proxyProd:findAll)
		{
			if (prod.getProductId().equals(proxyProd.getProductId())) {
				prod.setPrice(proxyProd.getPrice());
			}
		}
	 }
	 
	 return products;
}

}
