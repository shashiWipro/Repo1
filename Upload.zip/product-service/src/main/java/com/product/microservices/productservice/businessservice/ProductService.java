package com.product.microservices.productservice.businessservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.microservices.productservice.dao.ProductDao;
import com.product.microservices.productservice.entity.Product;

@Service
public class ProductService {

	@Autowired
	private ProductDao productDao;
	
	public List<Product> findAllProducts()
	{
		return productDao.findAll();
	}
	
	
	
	public Product findProductById(String productId)
	{
		return productDao.findById(productId).get();
	}
}
