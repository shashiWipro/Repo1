package com.bank.app.bankApplication.controllerTest;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import static org.mockito.Mockito.when;
import com.bank.app.bankApplication.controller.BankController;
import com.bank.app.bankApplication.entity.Account;
import com.bank.app.bankApplication.entity.Customer;
import com.bank.app.bankApplication.service.BankService;

 //imports: MockMvcRequestBuilders.*, MockMvcResultMatchers.*



@RunWith(SpringRunner.class)
@WebMvcTest(BankController.class)
public class BankControllerTest {
    @Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private BankService businessService;
	
	@Test
	public void getAccount() throws Exception
	{
	
		when(businessService.getAccount()).thenReturn(Arrays.asList(
				new Account("Saving",10000, new Customer("shashi","XXXXXXXXXX@GMAIL.COM","Banglore")),
				new Account("Current",13000, new Customer("bhushan","bhushan@gmail.com", "Indore") ),
				new Account("Current",25000,  new Customer("amir","amir@gmail.com", "mumbai")),
				new Account("Current",11000, new Customer("salman","salman@gmail.com", "darbhanga"))
		));
		
		RequestBuilder request=MockMvcRequestBuilders
				               .get("/accountDetails")
				               .accept(MediaType.APPLICATION_JSON);

		MvcResult res=mockMvc.perform(request).andReturn();
		System.out.println(res.getResponse());
		
		String expected1=
				"[{\"accountId\":null,\"accountType\":\"Saving\",\"balance\":9000,\"customer\":{\"customerId\":null,\"customerName\":\"shashi\",\"email\":\"XXXXXXXXXX@GMAIL.COM\",\"address\":\"Banglore\"}},{\"accountId\":null,\"accountType\":\"Current\",\"balance\":14000,\"customer\":{\"customerId\":null,\"customerName\":\"bhushan\",\"email\":\"bhushan@gmail.com\",\"address\":\"Indore\"}},{\"accountId\":null,\"accountType\":\"Current\",\"balance\":25000,\"customer\":{\"customerId\":null,\"customerName\":\"amir\",\"email\":\"amir@gmail.com\",\"address\":\"mumbai\"}},{\"accountId\":null,\"accountType\":\"Current\",\"balance\":11000,\"customer\":{\"customerId\":null,\"customerName\":\"salman\",\"email\":\"salman@gmail.com\",\"address\":\"darbhanga\"}}]";
		
		String expected=
	"[{accountId:1,accountType:Saving,balance:9000,customer:{customerId:2,customerName:shashi,email:XXXXXXXXXX@GMAIL.COM,address:Banglore}},"
	 + "{accountId:3,accountType:Current,balance:14000,customer:{customerId:4,customerName:bhushan,email:bhushan@gmail.com,address:Indore}},"
	+ "{accountId:5,accountType:Current,balance:25000,customer:{customerId:6,customerName:amir,email:amir@gmail.com,address:mumbai}},"
	+ "{accountId:7,accountType:Current,balance:11000,customer:{customerId:8,customerName:salman,email:salman@gmail.com,address:darbhanga}}]";
	
		
		String expected2="[{accountType:Saving}, {accountType:Current},{accountType:Current},{accountType:Current}]";
		//JSONAssert.assertEquals(expected2,res, false);
		//when(content().json(res.getResponse())).thenReturn(expected)
		
	MvcResult result= mockMvc.perform(request)
			            .andExpect(status().isOk())
		                 .andExpect(content().json(expected1))
		                 .andReturn();
		
	
  System.out.println(result);	
	}  
	
	
	@Test
	public void getAllAccountAPI() throws Exception 
	{
		mockMvc.perform( MockMvcRequestBuilders
	      .get("/accountDetails")
	      .accept(MediaType.APPLICATION_JSON))
	      .andExpect(status().isOk());
	}
	 
	
	@Test
	public void getAllAccountPathAPI() throws Exception 
	{
		mockMvc.perform( MockMvcRequestBuilders
	      .get("/accountDetails")
	      .accept(MediaType.APPLICATION_JSON))
	      .andExpect(status().isOk())
	      .andExpect(MockMvcResultMatchers.jsonPath("$.accountDetails").doesNotExist());
	      //.andExpect(MockMvcResultMatchers.jsonPath("$.accountDetails[*].accountId").isNotEmpty());
	}
	 
	
	@Test
	public void transferTest()
	{
		when(businessService.transferBalance(3, 1, 100)).thenReturn("Ammount Transfered Succesfully");
	}
	
	
	
	
	
}



