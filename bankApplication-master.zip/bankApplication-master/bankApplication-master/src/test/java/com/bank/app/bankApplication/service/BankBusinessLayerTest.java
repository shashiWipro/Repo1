package com.bank.app.bankApplication.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.bank.app.bankApplication.commandLineRunner.BankCommandLineRunner;
import com.bank.app.bankApplication.dao.AccountDAO;
import com.bank.app.bankApplication.entity.Account;


@RunWith(MockitoJUnitRunner.class)
public class BankBusinessLayerTest {
     
	@InjectMocks
	private BankService service;
	
	@Mock
	private AccountDAO accountDao;
	
	@Test
	public void initilize_Test() throws Exception
	{
		new BankCommandLineRunner().run();
	}
	
	@Test
	public void serviceTest_basic()
	{
     String expected=service.transferBalance(1, 3, 50);	
     assertEquals("Ammount Transfered Succesfully", expected);
    
    
    when(service.transferBalance(1, 3, 50)).thenReturn("Ammount Transfered Succesfully");
	}
	

	@Test
	public void calculateSum_basic() {
		BankService business = new BankService();
		List<Account> account = business.getAccount();
		System.out.println(account);
	}
	
	
	@Test
	public void serviceTest_basic_size()
	{
     List<Account> expected=service.getAccount();	
     assertEquals(0, expected.size());
    
	}
	
	
	
	

	@Test
	public void serviceTest_basic_getAcc()
	{
     Account expected=service.findAccountById(4);	
     assertEquals("Saving", expected.getAccountType());
    
	}
	
	
	@Test
	public void calculateSumUsingDataService_basic() {
		when(accountDao.existsById(1)).thenReturn(true);
		assertEquals(true, service.findAccountById(1));
	}

	
	
	
}
