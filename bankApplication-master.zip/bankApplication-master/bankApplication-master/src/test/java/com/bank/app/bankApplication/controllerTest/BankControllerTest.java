package com.bank.app.bankApplication.controllerTest;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.bank.app.bankApplication.controller.BankController;
import com.bank.app.bankApplication.entity.Account;
import com.bank.app.bankApplication.entity.Customer;
import com.bank.app.bankApplication.service.BankService;

 //imports: MockMvcRequestBuilders.*, MockMvcResultMatchers.*



@RunWith(SpringRunner.class)
@WebMvcTest(BankController.class)
public class BankControllerTest {
    @Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private BankService businessService;
	
	@Test
	public void getAccount() throws Exception
	{
	
		when(businessService.getAccount()).thenReturn(Arrays.asList(
				new Account("Saving",10000, new Customer("shashi","XXXXXXXXXX@GMAIL.COM","Banglore")),
				new Account("Current",13000, new Customer("bhushan","bhushan@gmail.com", "Indore") ),
				new Account("Current",25000,  new Customer("amir","amir@gmail.com", "mumbai")),
				new Account("Current",11000, new Customer("salman","salman@gmail.com", "darbhanga"))
		));
		
		RequestBuilder request=MockMvcRequestBuilders
				               .get("/accountDetails")
				               .accept(MediaType.APPLICATION_JSON);

		MvcResult res=mockMvc.perform(request).andReturn();
		System.out.println(res.getResponse());
		
		String expected1="[{accountType:Saving},{},{},{}]";
				
		
	
	MvcResult result= mockMvc.perform(request)
			            .andExpect(status().isOk())
		                 .andExpect(content().json(expected1))
		                 .andReturn();
		
	
  System.out.println(result);	
	}  
	
	
	@Test
	public void getAllAccountAPI() throws Exception 
	{
		mockMvc.perform( MockMvcRequestBuilders
	      .get("/accountDetails")
	      .accept(MediaType.APPLICATION_JSON))
	      .andExpect(status().isOk());
	}
	 
	
	@Test
	public void getAllAccountPathAPI() throws Exception 
	{
		mockMvc.perform( MockMvcRequestBuilders
	      .get("/accountDetails")
	      .accept(MediaType.APPLICATION_JSON))
	      .andExpect(status().isOk())
	      .andExpect(MockMvcResultMatchers.jsonPath("$.accountDetails").doesNotExist());
	      //.andExpect(MockMvcResultMatchers.jsonPath("$.accountDetails[*].accountId").isNotEmpty());
	}
	 
	
	
	/*
	 * @Test public void getBalanceTest() throws Exception {
	 * 
	 * when(businessService.getAccount(1).getBalance()).thenReturn( new
	 * Integer(10000)); mockMvc.perform( MockMvcRequestBuilders .get("/balance/{1}")
	 * .accept(MediaType.APPLICATION_JSON)) .andExpect(status().isOk())
	 * .andExpect(content().json("1000"));
	 * 
	 * }
	 */
	@Test
	public void transferTest()
	{
		when(businessService.transferBalance(3, 1, 100)).thenReturn("Ammount Transfered Succesfully");
	}
	
	

	
	
}



