package com.bank.app.bankApplication.controllerTest;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import static org.mockito.Mockito.times;
import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.mockito.Mockito.verify;
import com.bank.app.bankApplication.controller.CustomerController;
import com.bank.app.bankApplication.entity.Customer;
import com.bank.app.bankApplication.service.CustomerService;
import com.fasterxml.jackson.core.JsonProcessingException;
@RunWith(SpringRunner.class)
@WebMvcTest(CustomerController.class)
public class CustomerControllerTest {
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
    private  CustomerService customerService;
	
	@Test
	public void getCustomerById() throws Exception
	{
		RequestBuilder request=MockMvcRequestBuilders
				               .get("/allcustomer")
				               .accept(MediaType.APPLICATION_JSON);
		mockMvc.perform(request).andExpect(status().isOk());
	}
	
	
	/**
	 * @throws Exception
	 */
	@Test
	public void getCustomer_empty() throws Exception
	{
		RequestBuilder request=MockMvcRequestBuilders
				               .get("/allcustomer")
				               .accept(MediaType.APPLICATION_JSON);
		mockMvc.perform(request)
		       .andExpect(status().isOk())
		       .andExpect(content().json("[]"))
		       .andReturn();
		
	}
	
	
	@Test
	public void getTestCustomerById() throws Exception
	{
		when(customerService.getCustomerById(2)).thenReturn(new Customer("shashi","XXXXXXXXXX@GMAIL.COM","Banglore"));
		
	}
	
	
	@Test
	public void getTestCustomers() throws Exception
	{
		when(customerService.getCustomerDetails()).thenReturn(Arrays.asList(new Customer("shashi","XXXXXXXXXX@GMAIL.COM","Banglore"),
				                                             new Customer("bhushan","bhushan@gmail.com", "Indore") ,
				                                             new Customer("amir","amir@gmail.com", "mumbai"),
				                                             new Customer("salman","salman@gmail.com", "darbhanga"))
				                                              );
		RequestBuilder request=MockMvcRequestBuilders
				.get("/allcustomer")
				.accept(MediaType.APPLICATION_JSON);
		
		MvcResult result=mockMvc.perform(request)
				                .andExpect(content().json("[{customerName:shashi,email:XXXXXXXXXX@GMAIL.COM,address:Banglore},{},{},{}]"))
				                .andReturn();
		
	}

	
	@Test
	public void testAllData() throws JsonProcessingException, JSONException
	{
		when(customerService.getCustomerDetails()).thenReturn(Arrays.asList(
				new Customer("shashi","XXXXXXXXXX@GMAIL.COM","Banglore"),
                new Customer("bhushan","bhushan@gmail.com", "Indore") ,
                new Customer("amir","amir@gmail.com", "mumbai"),
                new Customer("salman","salman@gmail.com", "darbhanga"))
                 );
		
		RequestBuilder request=MockMvcRequestBuilders
	               .get("/allcustomer")
	               .accept(MediaType.APPLICATION_JSON);
		
		String actual="[{customerName:shashi,email:XXXXXXXXXX@GMAIL.COM,address:Banglore},{customerName:bhushan,email:bhushan@gmail.com,address:Indore},{customerName:amir,email:amir@gmail.com,address:mumbai},{customerName:salman,email:salman@gmail.com,address:darbhanga}]";
		
		

	}
	
	
	
	@Test
    public void createCustomerTest_Varify()
    {
        Customer customer = new Customer("Lokesh","user@email.com","Chennai");
         
        customerService.saveCustomer(customer);
         
        verify(customerService, times(1)).saveCustomer(customer);
    }
	
	
}
