package com.bank.app.bankApplication.daoTest;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.bank.app.bankApplication.dao.AccountDAO;
import com.bank.app.bankApplication.entity.Account;
import com.bank.app.bankApplication.entity.Customer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@DataJpaTest
public class BankDataLayerTest {
    
	@Autowired
	private AccountDAO accountDao;
	
	@Test
	public void testFindAllSize()
	{
	List<Account> accountList=accountDao.findAll();
	assertEquals(0,accountList.size());
	}
	
	@Test
	public void findOneAccountDetailsTest()
	{
		
	List<Account> accounts=accountDao.findByAccountType("Saving");
	System.out.println(accounts);
	assertEquals(true, accounts.isEmpty());
	}
	
	
	
	  @Test
	  public void testFindAllContains() throws JsonProcessingException, JSONException { 
		  System.out.println("####################Test######################");
		  List<Account>
	  accountList=accountDao.findAll();
		  ObjectMapper mapper = new ObjectMapper();
	      String jsonString = mapper.writeValueAsString(accountList); 
		  
	JSONAssert.assertEquals("[]", jsonString, false);
	  
	  }
	 
	  
	  @Test
		public void testSave() {
		  Customer cust=new Customer("shashi", "shashi@gmail.com", "Patna");
			Account idAccount=accountDao.save(new Account("Saving", 10000, new Custom))
			assertEquals("Saving",idAccount.getAccountType());
			System.out.println(idAccount.getAccountType()+"\t"+idAccount.getBalance());
		}

		
		@Test
		public void testfindAll() {
			List<Account> liAcc=new ArrayList<Account>();
			liAcc.add(new Account(111,"Saving",new Customer(1,"shashi Bhushan")));
			liAcc.add(new Account(222,"current",new Customer(2,"Rajkumar")));
			liAcc.add(new Account(333,"Demate",new Customer(3,"Vicky Kaushal")));
			accountDao.saveAll(liAcc);
			assertEquals(3,liAcc.size());
		}
}
