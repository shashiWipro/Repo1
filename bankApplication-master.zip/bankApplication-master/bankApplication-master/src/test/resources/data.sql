insert into Customer values(101,'shashi','shashi@gmail.com','Banglore');
insert into Customer values(102,'bhushan','bhushan@gmail.com','Patna');
insert into Customer values(103,'prasad','prasad@gmail.com','Chennai');
insert into Customer values(104,'Amir','Amir@gmail.com','Chandigadh');