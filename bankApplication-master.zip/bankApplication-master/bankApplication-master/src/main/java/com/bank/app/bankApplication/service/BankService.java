package com.bank.app.bankApplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.app.bankApplication.dao.AccountDAO;
import com.bank.app.bankApplication.entity.Account;

@Service
public class BankService {
	@Autowired
	private AccountDAO accDAO;	
	
	
	public List<Account> getAccount()
	{
		return accDAO.findAll();
	}
}
