package com.bank.app.bankApplication.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="CreditCardDetails")
public class CreditCardDetails {
   @Id
   @GeneratedValue
   @JsonProperty("id")
	private Integer id;
   @JsonProperty("panCardNo")
	private String panCardNo;
   @JsonProperty("creditScore")
	private Double creditScore;
	
	
	public CreditCardDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CreditCardDetails(String panCardNo, Double creditScore) {
		super();
		this.panCardNo = panCardNo;
		this.creditScore = creditScore;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPanCardNo() {
		return panCardNo;
	}
	public void setPanCardNo(String panCardNo) {
		this.panCardNo = panCardNo;
	}
	public Double getCreditScore() {
		return creditScore;
	}
	public void setCreditScore(Double creditScore) {
		this.creditScore = creditScore;
	}
	@Override
	public String toString() {
		return "CreditCardDetails [id=" + id + ", panCardNo=" + panCardNo + ", creditScore=" + creditScore + "]";
	}
	
	
}
