package com.bank.app.bankApplication.commandLineRunner;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.bank.app.bankApplication.dao.AccountDAO;
import com.bank.app.bankApplication.dao.CreditScoreDAO;
import com.bank.app.bankApplication.entity.Account;
import com.bank.app.bankApplication.entity.CreditCardDetails;
import com.bank.app.bankApplication.entity.Customer;
@Component
public class BankCommandLineRunner implements CommandLineRunner{
	@Autowired
	private AccountDAO accDAO;
   
	@Autowired
	private CreditScoreDAO creditScoreDAO;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("=================RUN Start================================");
		saveData();
		saveCreditScoreDetails();
		//getDetails();
		updateData();
		//getDetails();
		getAccountDetails();
		System.out.println("==================RUN End===============================");
		
		System.out.println("&&&&&&&&&&&&&&&&&&&&  * TRANSFER AMMOUNT  * &&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
		
		transferBalance(1, 3,1000);
		getAccountDetails();
		
		System.out.println("&&&&&&&&&&&&&&&&&&&&  * TRANSFER AMMOUNT END  * &&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
		
		
		System.out.println("****************Credit Score Details****************");
		
		
		findCreditScoreDetails();
		findScoreByPanNo("ABCD123");
	}
public void saveCreditScoreDetails()
{
	CreditCardDetails score1=new CreditCardDetails("ABCD123", 5.6);
	CreditCardDetails score2=new CreditCardDetails("XYCD768", 7.2);
	CreditCardDetails score3=new CreditCardDetails("AXYD908", 9.6);
	CreditCardDetails score4=new CreditCardDetails("LTNP657", 4.7);
	creditScoreDAO.save(score1);
	creditScoreDAO.save(score2);
	creditScoreDAO.save(score3);
	creditScoreDAO.save(score4);
}

public void findCreditScoreDetails()
{
 List<CreditCardDetails> creditDetails=	creditScoreDAO.findAll();
 for(CreditCardDetails cc:creditDetails)
     {
	 System.out.println("PanCard:"+cc.getPanCardNo()+"\tScore:"+cc.getCreditScore());
     }
}

	
	  public void findScoreByPanNo(String panCardNo) {
	  CreditCardDetails CScoreDetails=
	  creditScoreDAO.findByPanCardNo(panCardNo);
	  System.out.println(CScoreDetails.getCreditScore()); }
	 

	
public void saveData()
{
	Customer cust1=new Customer("shashi","shashi@gmail.com", "Banglore");
	Account ac1=new Account("Saving",10000, cust1);
    accDAO.save(ac1);
    
    
    Customer cust2=new Customer("bhushan","bhushan@gmail.com", "Indore");
	Account ac2=new Account("Current",13000, cust2);
    accDAO.save(ac2);
	
    
    Customer cust3=new Customer("amir","amir@gmail.com", "mumbai");
	Account ac3=new Account("Current",25000, cust3);
    accDAO.save(ac3);
	
    
    Customer cust4=new Customer("salman","salman@gmail.com", "darbhanga");
	Account ac4=new Account("Current",11000, cust4);
    accDAO.save(ac4);
   
}

public void getAccountDetails()
{
	  List<Account> acc=accDAO.findAll();
	  System.out.println("------------Account DETAILS  ***START---------------------"); 
	    for(Account ac:acc)
	    {
	    	System.out.println("Account ID:"+ac.getAccountId()+"\tAccount Holder Name:"+ac.getCustomer().getCustomerName()+"\tBalance:"+ac.getBalance());
	    	
	    }
	    
	    System.out.println("---------------Account Details ***END------------------"); 
	  
	   }


public void getCustomerDetails()
{
	  List<Account> acc=accDAO.findAll();
	    
	   System.out.println("------------CUSTOMER DETAILS**Start---------------------"); 
	    for(Account ac:acc)
	    {
	    	Customer cust=ac.getCustomer();
	    	System.out.println(cust);
	    	
	    }
	    System.out.println("-------------CUSTOMER DETAILS**END--------------------"); 
	   
	   }




 public void  updateData() {
	 System.out.println("************updateData****************");
	Optional<Account> ac =accDAO.findById(1);
	Account ac1=ac.get();
	System.out.println(ac1);
    System.out.println(ac);
	ac1.getCustomer().setEmail("XXXXXXXXXX@GMAIL.COM");
	accDAO.save(ac1);
                          }
 
 
 public  Account getAccount(Integer inputAccountId)
     {
	 Optional<Account> ac=accDAO.findById(inputAccountId);
	 return ac.get();
    }
 
 public void transferBalance(Integer fromAccount,Integer toAccount,Integer ammount)
 {
	 
	 Account fromAccountDetails=getAccount(fromAccount);
	 Account toAccountDetails=getAccount(toAccount);
	 toAccountDetails.setBalance(toAccountDetails.getBalance()+ammount);
	 fromAccountDetails.setBalance(fromAccountDetails.getBalance()-ammount);
	 
	 accDAO.save(fromAccountDetails);
	 accDAO.save(toAccountDetails);
	 
 }
	
}
