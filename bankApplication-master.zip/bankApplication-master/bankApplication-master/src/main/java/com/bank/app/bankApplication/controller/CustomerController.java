package com.bank.app.bankApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bank.app.bankApplication.entity.Customer;
import com.bank.app.bankApplication.service.CustomerService;

@RestController
public class CustomerController {
   
	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/allcustomer")
	public List<Customer> getCustomerDetails()
	{
		return customerService.getCustomerDetails();
	}
	
	
	
	@GetMapping("/customer/{customerId}")
	public Customer getCustomerById(@PathVariable Integer customerId)
	{
		return customerService.getCustomerById(customerId);
	}
	

	@DeleteMapping("/deleteCstomer/{customerId}")
	public String  deleteCustomerById(@PathVariable Integer customerId)
	{
      return customerService.deleteCustomerById(customerId);
	}
	
	@PostMapping("/savecustomer/{customer}")
	public String saveCustomer(@RequestBody Customer customer)
	{
	return	customerService.saveCustomer(customer);
	}
	
}
