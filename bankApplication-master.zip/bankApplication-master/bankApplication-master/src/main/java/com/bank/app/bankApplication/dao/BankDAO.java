package com.bank.app.bankApplication.dao;

public interface BankDAO {

}
