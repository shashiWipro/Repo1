package com.bank.app.bankApplication.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Account")
public class Account {
	@Id
	@GeneratedValue
private Integer accountId;
private String accountType;
private Integer balance;

@OneToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
@JoinColumn(name="customerId")
private Customer customer;
public Account(String accountType,Integer balance, Customer customer) {
	super();
	this.accountType = accountType;
	this.balance=balance;
	this.customer = customer;
}
public Account() {
	
}
public Integer getAccountId() {
	return accountId;
}
public void setAccountId(Integer accountId) {
	this.accountId = accountId;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public Customer getCustomer() {
	return customer;
}
public void setCustomer(Customer customer) {
	this.customer = customer;
}
public Integer getBalance() {
	return balance;
}
public void setBalance(Integer balance) {
	this.balance = balance;
}
@Override
public String toString() {
	//return "Account [accountId=" + accountId + ", accountType=" + accountType + ", customer=" + customer + "]";
	
	return "AccountId:"+accountId+"\tAccount Type:"+accountType+"\tCustomer:"+customer+"\tBalance:"+balance;
}

}
	