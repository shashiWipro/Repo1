package com.bank.app.bankApplication.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customer")
public class Customer {
	@Id
	@GeneratedValue
private Integer customerId;
private String customerName;
private String email;
private String address;

public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer(String customerName, String email, String address) {
	super();
	this.customerName = customerName;
	this.email = email;
	this.address = address;
}
public Integer getCustomerId() {
	return customerId;
}
public void setCustomerId(Integer customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}

@Override
public String toString() {
	//return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", email=" + email + ", address="
	//		+ address +  "]";
	
	return "\tCustomer ID:"+customerId+"\tCustomer Name:"+customerName+"\tEmail:"+email+"\tAddress:\t"+address;
}

}
