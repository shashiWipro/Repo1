package com.microservices.trainning.productviewservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductViewServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
