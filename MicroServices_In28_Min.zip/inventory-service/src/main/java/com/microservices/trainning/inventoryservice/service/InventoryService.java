package com.microservices.trainning.inventoryservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.microservices.trainning.inventoryservice.dao.InventoryDAO;
import com.microservices.trainning.inventoryservice.entity.Inventory;

@Service
public class InventoryService {
     
	@Autowired
	private InventoryDAO inventoryDAO;
	
	public Inventory saveInventoryDetails(@RequestBody Inventory inventory)
	{
		return inventoryDAO.save(inventory);
	}
	
	public Inventory findByProductId(String productId)
	{
		return inventoryDAO.findByProductId(productId);
	}
}
